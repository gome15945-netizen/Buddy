BulletTime64 - AML source project

Target:
- GTA San Andreas Android 2.10 64-bit
- AndroidModLoader (AML)
- SAUtils interface
- Existing Widget 38 (Power button) as the toggle

Behavior:
- Tap Widget 38 once: game time scale = 0.25x
- Tap Widget 38 again: game time scale = 1.0x
- No automatic timeout
- Restores 1.0x when the plugin unloads

Important:
This package is SOURCE CODE, not a precompiled .so.
It requires the Android NDK and the AML/SAUtils development headers.
The supplied isautils.h is the SAUtils header from the conversation.

The time-scale opcode is 015D (SET_TIME_SCALE), as defined by SAUtils's
sa_scripting.h / GTA scripting documentation.

Build:
1. Put the normal AML headers under include/mod/ from the AML SDK.
2. Keep include/isautils.h in place.
3. Run ndk-build.
4. The ARM64 output will be:
   libs/arm64-v8a/libBulletTime64.so

If your SAUtils version exposes Widget 38 differently, change:
   GetWidgetState(38, WState_Touched)
and
   ClearWidgetTapHistory(38)
to the verified widget ID.
