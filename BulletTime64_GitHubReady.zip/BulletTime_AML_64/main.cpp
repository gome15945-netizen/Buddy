#include <mod/amlmod.h>
#include <mod/logger.h>
#include "isautils.h"

static ISAUtils* sautils = nullptr;
static bool bulletTimeEnabled = false;
static void OnPlayerUpdate(uintptr_t info);

// GTA SA SCM opcode: SET_TIME_SCALE, one float parameter.
DEFOPCODE(015D, SET_TIME_SCALE, f);

static void SetGameTimeScale(float scale)
{
    if (sautils)
        sautils->ScriptCommand(&scm_SET_TIME_SCALE, scale);
}

ON_MOD_LOAD()
{
    logger->SetTag("BulletTime64");

    sautils = (ISAUtils*)GetInterface("SAUtils");
    if (!sautils)
    {
        logger->Error("SAUtils interface was not found.");
        return;
    }

    if (sautils->GetLoadedGame() != GTASA_2_10)
    {
        logger->Error("This plugin is intended for GTA SA 2.10.");
        return;
    }

    sautils->AddPlayerUpdateListener(OnPlayerUpdate, true);
    logger->Info("Bullet Time loaded. Toggle widget: 38 (Power button).");
}

ON_MOD_UNLOAD()
{
    // Always restore normal speed when the mod is unloaded.
    if (bulletTimeEnabled)
        SetGameTimeScale(1.0f);

    bulletTimeEnabled = false;
}

// Poll the existing in-game Power button (Widget 38).
// The same button toggles 0.25x <-> 1.0x.

static void OnPlayerUpdate(uintptr_t)
{
    if (!sautils)
        return;

    if (sautils->GetWidgetState(38, WState_Touched))
    {
        bulletTimeEnabled = !bulletTimeEnabled;
        SetGameTimeScale(bulletTimeEnabled ? 0.25f : 1.0f);

        // Prevent a single tap from being interpreted repeatedly.
        sautils->ClearWidgetTapHistory(38);

        logger->Info(bulletTimeEnabled
            ? "Bullet Time ON (0.25x)"
            : "Bullet Time OFF (1.0x)");
    }
}
